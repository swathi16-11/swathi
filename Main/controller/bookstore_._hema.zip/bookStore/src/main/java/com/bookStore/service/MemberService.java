package com.bookStore.service;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bookStore.entity.Book;
import com.bookStore.entity.Member;
import com.bookStore.repository.BookRepository;
import com.bookStore.repository.MemberRepository;
@Service
public class MemberService {
	@Autowired
	private MemberRepository mRepo;
	
	@Autowired
	private BookRepository bRepo;
	
	public boolean doesMemberExist(Integer id) {
        return mRepo.existsById(id);
    }
    
	public Iterable<Book> getAllBook(){
		return bRepo.findAll();
	}
	public Member addMember(Member member) {
	        return mRepo.save(member);
	    }
	public Optional<Member> getMemberById(Integer id) {
	        return mRepo.findById(id);
	    }
	
}
