package com.bookStore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import com.bookStore.entity.Book;
import com.bookStore.entity.Member;
import com.bookStore.entity.MyBookList;
import com.bookStore.service.BookService;
import com.bookStore.service.MemberService;
import com.bookStore.service.MyBookListService;

import java.util.*;

import javax.servlet.http.HttpSession;

@Controller
public class BookController {
	
	@Autowired
	private BookService service;
	
	@Autowired
	private MyBookListService myBookService;
	
	@Autowired
	private MemberService memberService;
	
	@GetMapping("/")
	public String home() {
		return "home";
	}
	
	@GetMapping("/book_register")
	public String bookRegister() {
		return "bookRegister";
	}
	
	@GetMapping("/available_books")
	public ModelAndView getAllBook() {
		Iterable<Book>list=service.getAllBook();
//		ModelAndView m=new ModelAndView();
//		m.setViewName("bookList");
//		m.addObject("book",list);
		return new ModelAndView("bookList","book",list);
	}
	
	@PostMapping("/save")
	public String addBook(@ModelAttribute Book b) {
		service.save(b);
		return "redirect:/available_books";
	}
	@GetMapping("/my_books")
	public String getMyBooks(Model model, HttpSession session) {
	  
	    int memberId = (int) session.getAttribute("memberId");
	    
	    List<MyBookList> list = myBookService.getMyBooksByMemberId(memberId);
	    model.addAttribute("book", list);
	    return "myBooks";
	}

	@RequestMapping("/mylist/{id}")
	public String getMyList(@PathVariable("id") int id, HttpSession session) {
	    Book b = service.getBookById(id);
	
	    int memberId = (int) session.getAttribute("memberId");
	    
	    Optional<Member> memberOptional = memberService.getMemberById(memberId);
	        Member member = memberOptional.get();
	       
	    MyBookList mb = new MyBookList( 1,b.getName(), b.getAuthor(), b.getYear(), member);
	    myBookService.saveMyBooks(mb);
	    return "redirect:/my_books";
	}


	@RequestMapping("/editBook/{id}")
	public String editBook(@PathVariable("id") int id,Model model) {
		Book b=service.getBookById(id);
		model.addAttribute("book",b);
		return "bookEdit";
	}
	@RequestMapping("/deleteBook/{id}")
	public String deleteBook(@PathVariable("id")int id) {
		service.deleteById(id);
		return "redirect:/available_books";
	}
	
}
