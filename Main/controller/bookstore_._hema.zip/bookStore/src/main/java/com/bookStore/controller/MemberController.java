package com.bookStore.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.bookStore.entity.Book;
import com.bookStore.entity.Member;
import com.bookStore.service.MemberService;
@Controller
public class MemberController {

	
	@Autowired
	private MemberService service;
	
	@GetMapping("/member_register")
	public String memberRegister(Model model) {
		 model.addAttribute("member", new Member());
		return "memberRegister";
	}
	 @GetMapping("/registerMember")
	    public String showRegistrationForm(Model model) {
	        
	        model.addAttribute("member", new Member());
	        return "memberRegister";
	    }
	 @PostMapping("/registerMember")
	 public String registerMember(@ModelAttribute("member") Member member, Model model) {
	     Member savedMember = service.addMember(member); 
	     model.addAttribute("memberId", savedMember.getId()); 
	     return "memberRegister"; 
	 }

	  
	
	 @RequestMapping("/login")
	    public ModelAndView getAllBook(@RequestParam("id") int id, HttpSession session) {
	        if (service.doesMemberExist(id)) {
	          
	            session.setAttribute("memberId", id);
	        
	            Iterable<Book> list = service.getAllBook();
	       
	            return new ModelAndView("bookList", "book", list);
	        } else {
	            
	            ModelAndView modelAndView = new ModelAndView();
	            modelAndView.setViewName("home"); 
	            modelAndView.addObject("errorMessage", "Member does not exist."); 
	            return modelAndView;
	        }
	    }


	}


