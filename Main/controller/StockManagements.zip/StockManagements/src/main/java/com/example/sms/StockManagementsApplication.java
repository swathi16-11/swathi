package com.example.sms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StockManagementsApplication {

	public static void main(String[] args) {
		SpringApplication.run(StockManagementsApplication.class, args);
	}

}
