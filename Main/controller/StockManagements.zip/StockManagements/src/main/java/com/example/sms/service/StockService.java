package com.example.sms.service;

import java.util.List;

import com.example.sms.model.Stock;

public interface StockService {
List<Stock> getAllStocks();
	
	void saveStock(Stock stock);
 
	Stock getStockById(int id);
	
	void deleteStockById(int id);
}
