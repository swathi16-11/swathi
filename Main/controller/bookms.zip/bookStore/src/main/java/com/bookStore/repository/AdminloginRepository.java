package com.bookStore.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bookStore.entity.Adminlogin;



@Repository



public interface AdminloginRepository extends JpaRepository<Adminlogin, Long>{





}






