package com.bookStore.repository;


import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.bookStore.entity.MyBookList;

@Repository
public interface MyBookRepository extends CrudRepository<MyBookList,Integer>{

}
