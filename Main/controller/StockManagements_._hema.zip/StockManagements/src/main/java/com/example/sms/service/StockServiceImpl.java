package com.example.sms.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.sms.model.Stock;
import com.example.sms.repository.StockRepository;

@Service
public class StockServiceImpl implements StockService{
	@Autowired
	private StockRepository stockRepository;

	@Override
	public List<Stock> getAllStocks() {

		return (List<Stock>) stockRepository.findAll();
	}

	@Override
	public void saveStock(Stock stock) {
		this.stockRepository.save(stock);

	}

	@Override
	public Stock getStockById(int id) {
		Optional<Stock> optional = stockRepository.findById(id);
		Stock stock = null;
		if (optional.isPresent()) {
			stock = optional.get();
		} else {
			throw new RuntimeException("Stock not found for id::" + id);
		}
		return stock;

	}

	@Override
	public void deleteStockById(int id) {
		this.stockRepository.deleteById(id);
	}

}

