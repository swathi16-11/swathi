package com.example.sms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.sms.model.Stock;
import com.example.sms.service.StockService;

@Controller
public class StockController {
	@Autowired
	private StockService stockService;
 
	@GetMapping("/")
	public String viewWelcomePage(Model model) {
		model.addAttribute("listStocks", stockService.getAllStocks());
		return "welcome";
	}
 
	// display list of properties
	@GetMapping("/listStocks")
	public String viewHomePage(Model model) {
		model.addAttribute("listStocks", stockService.getAllStocks());
		return "index";
	}
 
	@GetMapping("/showNewStockForm")
	public String showNewStockForm(Model model) {
		// creation-model attribute to bind data
		Stock stock = new Stock();
		model.addAttribute("stock", stock);
		return "new_stock";
	}
 
	@PostMapping("/saveStock")
	public String saveStock(@ModelAttribute("stock") Stock stock) {
		// Handle the file upload and save the property
		stockService.saveStock(stock);
		return "redirect:/listStocks";
	}
 
	@GetMapping("/showFormForUpdate/{id}")
	public String showFormForUpdate(@PathVariable(value = "id") int id, Model model) {
		Stock stock = stockService.getStockById(id);
		model.addAttribute("stock", stock);
		return "update_stock";
	}
	@PostMapping("/showFormForUpdate/{id}")
	public String updateStock(@ModelAttribute("stock") Stock stock, @PathVariable("id") int id) {
	    stockService.saveStock(stock);
	    return "redirect:/listStocks";
	}
	@GetMapping("/deleteStock/{id}")
	public String deleteStock(@PathVariable(value = "id") int id) {
		this.stockService.deleteStockById(id);
		return "redirect:/listStocks";
	}

}
